import {Component, ViewEncapsulation,} from '@angular/core';

@Component({
    selector: 'empty-route',
    template: '',
    encapsulation: ViewEncapsulation.None
})
export class EmptyRouteComponent {}
