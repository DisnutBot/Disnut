export const menus = {
    name: 'Menus',
    route: '/',
    fields: [],
};